// index.js — Malvin C XMD entry point
// Deploy this whole project on RENDER (Web Service). It runs an Express
// server that exposes a pairing API, and keeps the Baileys socket alive.
//
// The pairing WEBSITE (public/index.html) can be deployed separately on
// VERCEL — it just calls this server's /api/pair endpoint over the network.

const express = require('express');
const cors = require('cors');
const path = require('path');
const config = require('./config');
const { startSocket, getStatus, isReady } = require('./lib/whatsapp');

const app = express();
app.use(cors()); // allow the Vercel-hosted pairing page to call this API
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

let pairingInProgress = false;

app.get('/', (req, res) => {
    res.json({
        bot: config.BOT_NAME,
        poweredBy: config.POWERED_BY,
        status: getStatus(),
        message: 'Malvin C XMD backend is running. Use POST /api/pair to link a number.'
    });
});

app.get('/api/status', (req, res) => {
    res.json({ status: getStatus(), connected: isReady() });
});

// Body: { "number": "263771234567" }
app.post('/api/pair', async (req, res) => {
    try {
        if (isReady()) {
            return res.json({ success: true, alreadyConnected: true, message: 'Bot is already connected.' });
        }
        if (pairingInProgress) {
            return res.status(429).json({ success: false, message: 'A pairing request is already in progress, please wait.' });
        }

        const { number } = req.body;
        if (!number || !/^[0-9]{10,15}$/.test(number.replace(/[^0-9]/g, ''))) {
            return res.status(400).json({ success: false, message: 'Send a valid number in international format, e.g. 263771234567 (no + or spaces).' });
        }

        pairingInProgress = true;
        const code = await startSocket(number);
        pairingInProgress = false;

        if (!code) {
            return res.status(500).json({ success: false, message: 'Could not generate a pairing code. The session may already exist — delete the session folder on the server and try again.' });
        }

        res.json({ success: true, code });
    } catch (err) {
        pairingInProgress = false;
        console.error('Pairing error:', err);
        res.status(500).json({ success: false, message: err.message || 'Pairing failed.' });
    }
});

app.listen(config.PORT, () => {
    console.log(`🇿🇼 ${config.BOT_NAME} — ${config.POWERED_BY}`);
    console.log(`🚀 Server listening on port ${config.PORT}`);
    console.log(`📲 Open the pairing page and enter your WhatsApp number to link the bot.`);
});

// If a session already exists from a previous pairing, reconnect automatically
const fs = require('fs');
if (fs.existsSync(config.SESSION_DIR) && fs.readdirSync(config.SESSION_DIR).length > 0) {
    startSocket().catch(err => console.error('Auto-reconnect failed:', err.message));
}
