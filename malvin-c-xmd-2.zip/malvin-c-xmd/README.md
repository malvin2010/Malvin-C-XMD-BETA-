# Malvin C XMD

A WhatsApp Multi-Device bot built on [Baileys](https://github.com/WhiskeySockets/Baileys), pairing-code based (no QR scanning needed), with 100 working commands across general, fun, anime/reactions, group admin, owner, converter, downloader, and AI categories.

**Powered by Handsome Tech Zimbabwe 🇿🇼**

---

## ⚠️ How this is deployed (read this first)

This project is split across **two platforms** on purpose:

| Part | Platform | Why |
|---|---|---|
| `public/index.html` (pairing webpage) | **Vercel** | Static page, no server needed |
| Everything else (the actual bot: `index.js`, `commands/`, `lib/`) | **Render** | Baileys needs a constant live connection to WhatsApp. Vercel kills serverless functions after each request, so the bot would disconnect immediately if hosted there. Render keeps a real server running 24/7. |

So: **deploy the whole repo to Render** (that's where the bot lives and runs), and **deploy the same repo to Vercel too** — Vercel will only pick up the `public/` folder thanks to `vercel.json`, giving you a clean pairing webpage on its own URL.

---

## 🚀 Step-by-step deployment

### 1. Push this project to GitHub
Upload everything in this folder to your repo, e.g. `github.com/malvin2010/malvin-c-xmd`.

### 2. Deploy the bot backend to Render
1. Go to [render.com](https://render.com) → **New → Web Service**
2. Connect your GitHub repo
3. Render should auto-detect the `render.yaml` blueprint. If not, set manually:
   - **Build command:** `npm install`
   - **Start command:** `npm start`
   - **Plan:** Free
4. Add Environment Variables (Settings → Environment):
   - `OWNER_NUMBER` → your WhatsApp number, no `+`, e.g. `263771234567`
   - `OWNER_NAME` → your name
   - `PREFIX` → `.` (already default)
   - `GEMINI_API_KEY` → optional, only needed for `.ask` / `.chatbot` (get a free key at https://aistudio.google.com/app/apikey)
5. Deploy. Once live, copy your Render URL, e.g. `https://malvin-c-xmd.onrender.com`

> Render's free plan sleeps after inactivity and can take ~30-60s to wake up on the first pairing request — that's normal, just wait.

### 3. Connect the pairing page to your Render URL
Open `public/index.html` and edit this line near the bottom:
```js
const API_BASE_URL = 'https://YOUR-RENDER-APP-NAME.onrender.com';
```
Replace it with your real Render URL from step 2, then commit/push the change.

### 4. Deploy the pairing page to Vercel
1. Go to [vercel.com](https://vercel.com) → **New Project**
2. Import the same GitHub repo
3. Vercel will read `vercel.json` and serve only the `public/` folder automatically — no extra config needed
4. Deploy. You'll get a URL like `https://malvin-c-xmd.vercel.app`

---

## 📲 How to pair your WhatsApp number

1. Open your Vercel pairing page (e.g. `https://malvin-c-xmd.vercel.app`)
2. Type your number in international format, starting with the country code — no `+`, no spaces.
   - Zimbabwe example: `263771234567`
3. Tap **Generate Pairing Code**
4. On your phone: open **WhatsApp → Settings → Linked Devices → Link a Device → Link with phone number instead**
5. Enter the 8-character code shown on the website
6. Within a few seconds your bot will say it's connected — try sending `.menu` in any chat

Your session is saved on Render's disk, so the bot reconnects automatically after restarts — you only need to pair once (unless you log it out from WhatsApp).

---

## 🧩 Commands (100 total)

Type `.menu` in WhatsApp to see the live, categorized list. Categories:

- **General (6):** ping, alive, menu, owner, runtime, report
- **Fun (15):** joke, quote, fact, truth, dare, compliment, roast, 8ball, flirt, riddle, wouldurather, advice, ship, simp, meme
- **Anime & Reactions (31):** waifu, neko, hug, kiss, pat, slap, dance, and more — powered by waifu.pics
- **Group Admin (14):** kick, add, promote, demote, mute, unmute, tagall, hidetag, welcome, antilink, setdesc, setname, grouplink, revoke
- **Owner (9):** broadcast, ban, unban, mode, setpp, setbio, block, unblock, stats
- **Converter (6):** sticker, toimg, togif, tomp3, take, vv
- **Downloader (5):** play, song, video, tiktok, lyrics
- **AI (2):** ask, chatbot
- **Tools (12):** calc, translate, weather, shorturl, qr, define, currency, time, base64, color, poll, reverse

### Adding more commands
Drop a new `.js` file into the matching `commands/<category>/` folder following this shape:
```js
module.exports = {
    name: 'mycommand',
    category: 'tools',
    description: 'What it does',
    execute: async (sock, msg, args, { jid, prefix, config }) => {
        await sock.sendMessage(jid, { text: 'Hello!' }, { quoted: msg });
    }
};
```
It's picked up automatically on the next restart — no need to register it anywhere else.

---

## 🛠️ Local testing (optional)

```bash
npm install
cp .env.example .env   # fill in your values
npm start
```
Then open `http://localhost:3000` in a browser and use a tool like `curl` or the pairing page (pointed at `http://localhost:3000`) to pair.

---

## Honest notes

- **Downloader commands** (`.play`, `.song`, `.video`) rely on YouTube extraction libraries that occasionally break when YouTube changes something on their end. If they stop working, check for an update to `@distube/ytdl-core` in `package.json`.
- **`.tiktok`** relies on the third-party tikwm.com service. If TikTok changes their API it may need a replacement service.
- **AI commands** (`.ask`, `.chatbot`) need a free `GEMINI_API_KEY` set on Render. Without it, they'll politely tell the user it's not configured instead of crashing.
- Render's free tier sleeps when idle. For a bot that's always online, you'll eventually want a paid Render plan or a uptime pinger.

---

🇿🇼 Built by **Handsome Tech Zimbabwe**
