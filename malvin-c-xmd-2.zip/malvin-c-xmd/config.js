// config.js — Malvin C XMD configuration
// Edit these values or set them as Environment Variables on Render.

require('dotenv').config();

module.exports = {
    // Command prefix — every command starts with this
    PREFIX: process.env.PREFIX || '.',

    // Bot identity
    BOT_NAME: 'Malvin C XMD',
    OWNER_NAME: process.env.OWNER_NAME || 'Malvin',
    OWNER_NUMBER: process.env.OWNER_NUMBER || '263000000000', // your WhatsApp number, no + or spaces
    POWERED_BY: 'Handsome Tech Zimbabwe 🇿🇼',

    // Pairing
    // The bot's own WhatsApp number is supplied at runtime via the pairing
    // website (public/index.html) -> POST /api/pair, so nothing to set here.

    // Auto features
    AUTO_READ: process.env.AUTO_READ === 'true' || false,
    AUTO_JOIN: true, // auto-add new contacts/groups welcome behaviour used by commands

    // Optional: free Gemini API key for the .ask / .chatbot AI commands.
    // Get one free at https://aistudio.google.com/app/apikey
    GEMINI_API_KEY: process.env.GEMINI_API_KEY || '',

    // Server port (Render sets process.env.PORT automatically)
    PORT: process.env.PORT || 3000,

    // Where Baileys session credentials are stored
    SESSION_DIR: process.env.SESSION_DIR || './session'
};
